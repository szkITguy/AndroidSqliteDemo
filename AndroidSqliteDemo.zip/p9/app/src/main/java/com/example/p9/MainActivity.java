package com.example.p9;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    dbhelper mydb;

    EditText id,name,sname,marks;
    Button b1,b2,b3,b4;
    TextView t1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mydb=new dbhelper(this);

        id=(EditText)findViewById(R.id.ed5);
        name=(EditText)findViewById(R.id.ed1);
        sname=(EditText)findViewById(R.id.ed2);
        marks=(EditText)findViewById(R.id.ed3);
        b1=(Button) findViewById(R.id.b1);
        b2=(Button) findViewById(R.id.b2);
        b3=(Button) findViewById(R.id.b3);
        b4=(Button) findViewById(R.id.b4);

        t1=(TextView)findViewById(R.id.t1);
        t1.setMovementMethod(new ScrollingMovementMethod());

        ////Insert
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String name1,sname1,marks1;

                name1=name.getText().toString();
                sname1=sname.getText().toString();
                marks1=marks.getText().toString();

                mydb.insertData(name1,sname1,marks1);

                Toast.makeText(getApplicationContext(),"Data inserted",Toast.LENGTH_SHORT).show();
            }
        });


        /////Display
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                t1.setText("");
               Cursor res= mydb.getdata();

               while(res.moveToNext()) {
                   t1.append("Id : " + res.getString(0)+"\n");
                   t1.append("Name : " + res.getString(1)+"\n");
                   t1.append("Surname : " + res.getString(2)+"\n");
                   t1.append("Marks : " + res.getString(3)+"\n\n");
               }
            }
        });


        ///////Update
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                t1.setText("");
                String id1,name1,sname1,marks1;
                id1=id.getText().toString();
                name1=name.getText().toString();
                sname1=sname.getText().toString();
                marks1=marks.getText().toString();

                mydb.updateData(id1,name1,sname1,marks1);
            }
        });


        ///////Delete
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                t1.setText("");
                String id1;
                id1=id.getText().toString();

                mydb.deleteData(id1);
            }
        });


    }
}